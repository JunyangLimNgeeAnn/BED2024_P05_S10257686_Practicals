const express = require("express");
const booksController = require("./Controllers/bookscontroller");
const sql = require("mssql");
const dbConfig = require("./dbconfig");
const staticMiddleware = express.static("public"); // Path to the public folder
const bodyParser = require("body-parser")
const path = require("path");


const app = express();
const port = process.env.PORT || 3006; // Use environment variable or default port

app.use(express.static(path.join(__dirname, "public")));


// Routes for GET requests (replace with appropriate routes for update and delete later)
app.get("/books", booksController.getAllBooks);
app.get("/books/:id", booksController.getBookById);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true })); 

app.use(staticMiddleware); // Mount the static middleware

app.listen(port, async () => {
  try {
    // Connect to the database
    await sql.connect(dbConfig);
    console.log("Database connection established successfully");
  } catch (err) {
    console.error("Database connection error:", err);
    // Terminate the application with an error code (optional)
    process.exit(1); // Exit with code 1 indicating an error
  }

  console.log(`Server listening on port ${port}`);
});

// Close the connection pool on SIGINT signal
process.on("SIGINT", async () => {
  console.log("Server is gracefully shutting down");
  // Perform cleanup tasks (e.g., close database connections)
  await sql.close();
  console.log("Database connection closed");
  process.exit(0); // Exit with code 0 indicating successful shutdown
});